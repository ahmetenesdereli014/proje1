-- =========================================================================
-- PROJE: ÖĞRENCİ BİLGİ SİSTEMİ VERİTABANI TASARIMI
-- =========================================================================
-- Bu veritabanı, bir üniversitenin öğrenci işleri otomasyonunu yönetmek amacıyla
-- 3. Normal Form (3NF) kurallarına göre tasarlanmıştır. Akademik bölümler,
-- öğretim üyeleri, ders programı, sınav bilgileri, öğrenci notları ve
-- devamsızlık kayıtlarını barındırır.

-- Veritabanı varsa silip yeniden oluşturuyoruz (T-SQL Uyumlu)
IF EXISTS (SELECT * FROM sys.databases WHERE name = 'OgrenciBilgiSistemi')
BEGIN
    ALTER DATABASE OgrenciBilgiSistemi SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE OgrenciBilgiSistemi;
END
CREATE DATABASE OgrenciBilgiSistemi;
GO

USE OgrenciBilgiSistemi;
GO

-- =========================================================================
-- TABLOLARIN OLUŞTURULMASI (DDL)
-- =========================================================================

-- 1. BÖLÜMLER TABLOSU
CREATE TABLE Bolumler (
    BolumID INT IDENTITY(1,1) PRIMARY KEY,
    BolumAdi VARCHAR(100) NOT NULL
);

-- 2. ÖĞRETİM ÜYELERİ TABLOSU
CREATE TABLE OgretimUyeleri (
    OgretimUyesiID INT IDENTITY(1,1) PRIMARY KEY,
    Unvan VARCHAR(30) NOT NULL, -- Prof. Dr., Doç. Dr., Dr. Öğr. Üyesi vb.
    Ad VARCHAR(50) NOT NULL,
    Soyad VARCHAR(50) NOT NULL,
    BolumID INT FOREIGN KEY REFERENCES Bolumler(BolumID) ON DELETE SET NULL
);

-- 3. DERSLER TABLOSU
CREATE TABLE Dersler (
    DersID INT IDENTITY(1,1) PRIMARY KEY,
    DersKodu VARCHAR(10) UNIQUE NOT NULL, -- BIL101, MAT202 vb.
    DersAdi VARCHAR(100) NOT NULL,
    Kredi INT NOT NULL,
    Akts INT NOT NULL,
    OgretimUyesiID INT FOREIGN KEY REFERENCES OgretimUyeleri(OgretimUyesiID) ON DELETE SET NULL
);

-- 4. ÖĞRENCİLER TABLOSU
CREATE TABLE Ogrenciler (
    OgrenciID INT IDENTITY(1,1) PRIMARY KEY,
    OgrenciNo VARCHAR(15) UNIQUE NOT NULL,
    Ad VARCHAR(50) NOT NULL,
    Soyad VARCHAR(50) NOT NULL,
    BolumID INT FOREIGN KEY REFERENCES Bolumler(BolumID) ON DELETE NO ACTION,
    KayitYili INT NOT NULL
);

-- 5. ÖĞRENCİ-DERS İLİŞKİ TABLOSU (Ara Tablo / Junction Table)
-- [BİRDEN ÇOK İLİŞKİ - Many-to-Many]
-- Bir öğrenci birden çok ders alabilir, bir dersi birden çok öğrenci seçebilir.
CREATE TABLE OgrenciDersler (
    OgrenciID INT FOREIGN KEY REFERENCES Ogrenciler(OgrenciID) ON DELETE CASCADE,
    DersID INT FOREIGN KEY REFERENCES Dersler(DersID) ON DELETE CASCADE,
    VizeNotu INT CHECK (VizeNotu BETWEEN 0 AND 100),
    FinalNotu INT CHECK (FinalNotu BETWEEN 0 AND 100),
    Ortalama AS (VizeNotu * 0.40 + FinalNotu * 0.60) PERSISTED, -- Otomatik hesaplanan kolon
    PRIMARY KEY (OgrenciID, DersID)
);

-- 6. SINAVLAR TABLOSU
CREATE TABLE Sinavlar (
    SinavID INT IDENTITY(1,1) PRIMARY KEY,
    DersID INT FOREIGN KEY REFERENCES Dersler(DersID) ON DELETE CASCADE,
    SinavTipi VARCHAR(20) NOT NULL, -- Vize, Final, Bütünleme
    Tarih DATETIME NOT NULL,
    SinavSalon VARCHAR(30)
);

-- 7. DEVAMSIZLIK TABLOSU
CREATE TABLE Devamsizlik (
    DevamsizlikID INT IDENTITY(1,1) PRIMARY KEY,
    OgrenciID INT FOREIGN KEY REFERENCES Ogrenciler(OgrenciID) ON DELETE CASCADE,
    DersID INT FOREIGN KEY REFERENCES Dersler(DersID) ON DELETE CASCADE,
    Tarih DATE NOT NULL,
    Saat INT NOT NULL -- Devamsızlık yapılan ders saati
);
GO

-- =========================================================================
-- ÖRNEK VERİLERİN EKLENMESİ (DML)
-- =========================================================================

-- Bölümler Ekleme
INSERT INTO Bolumler (BolumAdi) VALUES 
('Bilgisayar Mühendisliği'), 
('Elektrik-Elektronik Mühendisliği'), 
('Makine Mühendisliği'),
('Endüstri Mühendisliği'),
('Yapay Zeka Mühendisliği'); -- Henüz öğrencisi yok (LEFT JOIN için kullanılacak)

-- Öğretim Üyeleri Ekleme
INSERT INTO OgretimUyeleri (Unvan, Ad, Soyad, BolumID) VALUES 
('Prof. Dr.', 'Ahmet', 'Yılmaz', 1),
('Doç. Dr.', 'Elif', 'Kaya', 1),
('Dr. Öğr. Üyesi', 'Mehmet', 'Demir', 2),
('Prof. Dr.', 'Ayşe', 'Aydın', 3),
('Doç. Dr.', 'Hasan', 'Yıldız', 4);

-- Dersler Ekleme
INSERT INTO Dersler (DersKodu, DersAdi, Kredi, Akts, OgretimUyesiID) VALUES 
('BIL101', 'Programlamaya Giriş', 4, 6, 1),
('BIL203', 'Veritabanı Yönetim Sistemleri', 3, 5, 2),
('EEM201', 'Devre Teorisi', 4, 6, 3),
('MAK301', 'Akışkanlar Mekaniği', 3, 5, 4),
('END204', 'Yöneylem Araştırması', 4, 6, 5),
('BIL405', 'Yapay Zeka Uygulamaları', 3, 5, 2);

-- Öğrenciler Ekleme
INSERT INTO Ogrenciler (OgrenciNo, Ad, Soyad, BolumID, KayitYili) VALUES 
('20240101', 'Can', 'Öztürk', 1, 2024),
('20240102', 'Buse', 'Şahin', 1, 2024),
('20250201', 'Murat', 'Çelik', 2, 2025),
('20230301', 'Zeynep', 'Kılıç', 3, 2023),
('20240401', 'Deniz', 'Yalçın', 4, 2024);

-- Öğrenci Ders Seçimleri ve Notları
INSERT INTO OgrenciDersler (OgrenciID, DersID, VizeNotu, FinalNotu) VALUES 
(1, 1, 80, 85), -- Can -> Programlamaya Giriş
(1, 2, 70, 75), -- Can -> Veritabanı
(2, 1, 55, 60), -- Buse -> Programlamaya Giriş
(2, 2, 90, 85), -- Buse -> Veritabanı
(3, 3, 40, 50), -- Murat -> Devre Teorisi
(4, 4, 75, 80), -- Zeynep -> Akışkanlar Mekaniği
(5, 5, 85, 90), -- Deniz -> Yöneylem Araştırması
(1, 6, 95, 100); -- Can -> Yapay Zeka Uygulamaları

-- Sınav Takvimi Ekleme
INSERT INTO Sinavlar (DersID, SinavTipi, Tarih, SinavSalon) VALUES 
(1, 'Vize', '2026-04-15 10:00:00', 'D201 LAB'),
(2, 'Vize', '2026-04-16 14:00:00', 'D102 LAB'),
(3, 'Vize', '2026-04-17 09:00:00', 'Amfi-1'),
(4, 'Vize', '2026-04-18 11:00:00', 'Amfi-3'),
(5, 'Vize', '2026-04-19 15:00:00', 'B104 Sınıf');

-- Devamsızlık Kayıtları
INSERT INTO Devamsizlik (OgrenciID, DersID, Tarih, Saat) VALUES 
(1, 1, '2026-03-05', 2),
(1, 2, '2026-03-12', 3),
(3, 3, '2026-03-10', 4),
(2, 1, '2026-03-05', 2);
GO

-- =========================================================================
-- KRİTER 1: 4 ADET JOIN SORGUSU
-- =========================================================================

-- Sorgu 1.1: Ders alan öğrencilerin listesi (Öğrenci Ad-Soyad, No, Ders Adı ve Not Bilgileri)
-- (Ogrenciler, OgrenciDersler, Dersler - 3 Tablo INNER JOIN)
SELECT 
    O.OgrenciNo,
    O.Ad + ' ' + O.Soyad AS OgrenciAdiSoyad,
    D.DersKodu,
    D.DersAdi,
    OD.VizeNotu,
    OD.FinalNotu,
    OD.Ortalama
FROM Ogrenciler O
INNER JOIN OgrenciDersler OD ON O.OgrenciID = OD.OgrenciID
INNER JOIN Dersler D ON OD.DersID = D.DersID;

-- Sorgu 1.2: Öğretim üyelerini, verdikleri dersleri ve bu derslerin ait olduğu bölümü listeleyen sorgu
-- (OgretimUyeleri, Dersler, Bolumler - 3 Tablo INNER JOIN)
SELECT 
    OU.Unvan + ' ' + OU.Ad + ' ' + OU.Soyad AS OgretimUyesi,
    D.DersKodu + ' - ' + D.DersAdi AS DersBilgisi,
    B.BolumAdi
FROM OgretimUyeleri OU
INNER JOIN Dersler D ON OU.OgretimUyesiID = D.OgretimUyesiID
INNER JOIN Bolumler B ON OU.BolumID = B.BolumID;

-- Sorgu 1.3: Tüm bölümleri ve bu bölümlere kayıtlı öğrencilerin sayılarını gösteren sorgu
-- (Bölümlerde henüz hiç öğrenci olmasa dahi LEFT JOIN ile gösterilir)
SELECT 
    B.BolumAdi,
    O.OgrenciNo,
    O.Ad + ' ' + O.Soyad AS OgrenciAdiSoyad
FROM Bolumler B
LEFT JOIN Ogrenciler O ON B.BolumID = O.BolumID;

-- Sorgu 1.4: Öğrencilerin devamsızlık durumlarını ve ders bazlı toplam devamsızlık saatlerini listeleyen sorgu
-- (Ogrenciler, Devamsizlik, Dersler - INNER JOIN)
SELECT 
    O.OgrenciNo,
    O.Ad + ' ' + O.Soyad AS OgrenciAdiSoyad,
    D.DersAdi,
    SUM(DEV.Saat) AS ToplamDevamsizlikSaati
FROM Ogrenciler O
INNER JOIN Devamsizlik DEV ON O.OgrenciID = DEV.OgrenciID
INNER JOIN Dersler D ON DEV.DersID = D.DersID
GROUP BY O.OgrenciNo, O.Ad, O.Soyad, D.DersAdi;
GO

-- =========================================================================
-- KRİTER 2: 3 ADET HAVING SORGUSU
-- =========================================================================

-- Sorgu 2.1: Sınıf başarı düzeyi analizi: Sınıf ortalama notu (Vize ve Finalin harmanı) 70'ten büyük olan dersleri ve bu dersi alan öğrenci sayısını listeleyen sorgu
SELECT 
    D.DersAdi,
    COUNT(OD.OgrenciID) AS DersiAlanOgrenciSayisi,
    AVG(OD.Ortalama) AS SinifOrtalamasi
FROM Dersler D
INNER JOIN OgrenciDersler OD ON D.DersID = OD.DersID
GROUP BY D.DersID, D.DersAdi
HAVING AVG(OD.Ortalama) >= 70.0;

-- Sorgu 2.2: Sistemde kayıtlı öğrenci sayısı 1'den fazla olan aktif bölümleri listeleyen HAVING sorgusu
SELECT 
    B.BolumAdi,
    COUNT(O.OgrenciID) AS KayitliOgrenciSayisi
FROM Bolumler B
INNER JOIN Ogrenciler O ON B.BolumID = O.BolumID
GROUP BY B.BolumID, B.BolumAdi
HAVING COUNT(O.OgrenciID) > 1;

-- Sorgu 2.3: Dönemlik ders yükü analizi: Toplamda verdiği derslerin kredi sayısı 6'dan fazla olan öğretim üyelerini ve toplam kredilerini listeleyen HAVING sorgusu
SELECT 
    OU.Unvan + ' ' + OU.Ad + ' ' + OU.Soyad AS OgretimUyesi,
    SUM(D.Kredi) AS ToplamDersKredisi,
    COUNT(D.DersID) AS VerdigiDersSayisi
FROM OgretimUyeleri OU
INNER JOIN Dersler D ON OU.OgretimUyesiID = D.OgretimUyesiID
GROUP BY OU.OgretimUyesiID, OU.Unvan, OU.Ad, OU.Soyad
HAVING SUM(D.Kredi) >= 6;
GO
